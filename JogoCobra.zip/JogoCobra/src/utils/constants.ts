import { Posicao } from "../types/types";

// Tamanho do tabuleiro (10x10, como especificado)
export const GRID_SIZE = 10;

// Tamanho de cada célula em px
export const CELULA = 30;

// Direções possíveis
export const DIRECOES = {
  CIMA: { x: 0, y: -1 },
  BAIXO: { x: 0, y: 1 },
  ESQUERDA: { x: -1, y: 0 },
  DIREITA: { x: 1, y: 0 },
};

// Função para comparar posições
export function igual(a: Posicao, b: Posicao): boolean {
  return a.x === b.x && a.y === b.y;
}

// -------------------------------------------
//   GERAR COMIDA SEM ERROS (VERSÃO FINAL)
// -------------------------------------------
// Garante que:
// ✔ posição é sempre aleatória
// ✔ dentro do tabuleiro
// ✔ não colide com a cobra
export function gerarComida(cobra: Posicao[]): Posicao {
  let pos: Posicao;

  do {
    pos = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
  } while (cobra.some(seg => seg.x === pos.x && seg.y === pos.y));

  return pos;
}
