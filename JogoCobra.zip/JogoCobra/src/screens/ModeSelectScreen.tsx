// src/screens/ModeSelectionScreen.tsx
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Modo } from "../types/types";

export default function ModeSelectionScreen({
  onSelect,
}: {
  onSelect: (modo: Modo) => void;
}) {
  return (
    <View style={styles.root}>
      <Text style={styles.title}>Escolher Modo</Text>

      {/* FÁCIL */}
      <TouchableOpacity
        style={styles.btn}
        onPress={() => onSelect("FACIL")}
      >
        <Text style={styles.btnText}>Fácil</Text>
      </TouchableOpacity>

      {/* MÉDIO */}
      <TouchableOpacity
        style={styles.btn}
        onPress={() => onSelect("MEDIO")}
      >
        <Text style={styles.btnText}>Médio</Text>
      </TouchableOpacity>

      {/* DIFÍCIL */}
      <TouchableOpacity
        style={styles.btn}
        onPress={() => onSelect("DIFICIL")}
      >
        <Text style={styles.btnText}>Difícil</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 28,
    color: "#fff",
    marginBottom: 20,
    fontWeight: "700",
  },
  btn: {
    backgroundColor: "#4caf50",
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginVertical: 10,
  },
  btnText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
});
