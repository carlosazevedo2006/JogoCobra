import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

interface WelcomeScreenProps {
  onContinue: () => void;
}

export default function WelcomeScreen({ onContinue }: WelcomeScreenProps) {
  return (
    <View style={styles.root}>
      <Text style={styles.title}>JOGO DA COBRA</Text>

      <Text style={styles.subtitle}>
        Bem-vindo ao clássico Snake!
        {"\n"}Desvia-te das paredes e do teu corpo.
        {"\n"}Apanha comida para cresceres!
      </Text>

      <TouchableOpacity style={styles.playBtn} onPress={onContinue}>
        <Text style={styles.playText}>Começar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },

  title: {
    fontSize: 32,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 16,
  },

  subtitle: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: "center",
    color: "#ccc",
    marginBottom: 32,
  },

  playBtn: {
    backgroundColor: "#4caf50",
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 10,
  },

  playText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
});
