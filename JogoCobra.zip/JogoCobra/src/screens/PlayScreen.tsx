import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

interface PlayScreenProps {
  onChooseMode: () => void;
}

export default function PlayScreen({ onChooseMode }: PlayScreenProps) {
  return (
    <View style={styles.root}>
      <Text style={styles.title}>Jogar</Text>

      <TouchableOpacity style={styles.playBtn} onPress={onChooseMode}>
        <Text style={styles.playText}>Escolher Modo</Text>
      </TouchableOpacity>

      <View style={styles.instructionsBox}>
        <Text style={styles.instructionsTitle}>Como Jogar</Text>

        <Text style={styles.instructionsText}>
          • Deslize o dedo para mover a cobra.
        </Text>
        <Text style={styles.instructionsText}>
          • Evite paredes e o próprio corpo.
        </Text>
        <Text style={styles.instructionsText}>
          • Coma a comida para crescer.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },

  title: {
    fontSize: 32,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 16,
  },

  playBtn: {
    backgroundColor: "#4caf50",
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 10,
    marginBottom: 20,
  },

  playText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },

  instructionsBox: {
    width: "80%",
    backgroundColor: "#222",
    padding: 14,
    borderRadius: 10,
  },

  instructionsTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 8,
    textAlign: "center",
  },

  instructionsText: {
    color: "#ccc",
    fontSize: 14,
    marginBottom: 4,
  },
});
