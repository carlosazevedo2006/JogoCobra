import { useState } from "react";
import { GRID_SIZE, igual } from "../utils/constants";
import { Posicao } from "../types/types";

export default function useEnemyMovement({ modoSelecionado, cobra, terminarJogo }: any) {
  const [cobraInimiga, setCobraInimiga] = useState<Posicao[]>([
    { x: GRID_SIZE - 2, y: GRID_SIZE - 2 },
  ]);

  function moverCobraInimiga() {
    if (modoSelecionado !== "DIFICIL") return;

    const head = cobraInimiga[0];
    const target = cobra[0];

    const dx = target.x - head.x;
    const dy = target.y - head.y;

    const stepX = dx === 0 ? 0 : dx > 0 ? 1 : -1;
    const stepY = dy === 0 ? 0 : dy > 0 ? 1 : -1;

    const nova = { x: head.x + stepX, y: head.y + stepY };

    if (igual(nova, target)) {
      terminarJogo();
      return;
    }

    if (
      nova.x < 0 || nova.x >= GRID_SIZE ||
      nova.y < 0 || nova.y >= GRID_SIZE
    ) {
      return;
    }

    setCobraInimiga([nova]);
  }

  return {
    cobraInimiga,
    setCobraInimiga,
    moverCobraInimiga,
  };
}
