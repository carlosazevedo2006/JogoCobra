// Tipos globais utilizados no jogo

// Representa uma posição (x,y) no tabuleiro
export interface Posicao {
  x: number;
  y: number;
}

// Enum dos modos de jogo
export type Modo = "FACIL" | "MEDIO" | "DIFICIL";
