import React from "react";
import { Animated, StyleSheet } from "react-native";
import { CELULA } from "../utils/constants";
import { Posicao } from "../types/types";

interface SnakeSegmentProps {
  segment: Posicao;
  animation?: Animated.ValueXY;
  color: string;
}

export default function SnakeSegment({ segment, animation, color }: SnakeSegmentProps) {
  const transformStyle = animation
    ? [{ translateX: animation.x }, { translateY: animation.y }]
    : [
        { translateX: segment.x * CELULA },
        { translateY: segment.y * CELULA },
      ];

  return (
    <Animated.View style={[styles.segment, { backgroundColor: color }, { transform: transformStyle }]} />
  );
}

const styles = StyleSheet.create({
  segment: {
    position: "absolute",
    width: CELULA - 4,
    height: CELULA - 4,
    borderRadius: 5,
  },
});
