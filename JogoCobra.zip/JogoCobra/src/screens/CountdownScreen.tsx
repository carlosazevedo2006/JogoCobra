import React from "react";
import { View, Text, StyleSheet } from "react-native";

interface CountdownScreenProps {
  value: number;
}

export default function CountdownScreen({ value }: CountdownScreenProps) {
  return (
    <View style={styles.root}>
      <Text style={styles.countdown}>
        {value > 0 ? value : "JÁ!"}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
  },

  countdown: {
    fontSize: 70,
    color: "#fff",
    fontWeight: "700",
  },
});
