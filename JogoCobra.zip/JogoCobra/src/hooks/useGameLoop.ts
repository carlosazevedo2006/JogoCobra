import { useEffect, useRef } from "react";

export default function useGameLoop(jogando: boolean, velocidade: number, tick: () => void) {
  const lastTimeRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  function loop(t?: number) {
    if (!lastTimeRef.current) lastTimeRef.current = t || 0;

    const delta = (t || 0) - lastTimeRef.current;

    if (jogando && delta >= velocidade) {
      tick();
      lastTimeRef.current = t || 0;
    }

    rafRef.current = requestAnimationFrame(loop);
  }

  useEffect(() => {
    rafRef.current = requestAnimationFrame(loop);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [jogando, velocidade]);
}
