import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

interface GameOverScreenProps {
  score: number;
  best: number;
  onRestart: () => void;
  onBackToMenu: () => void;
}

export default function GameOverScreen({
  score,
  best,
  onRestart,
  onBackToMenu,
}: GameOverScreenProps) {
  return (
    <View style={styles.root}>
      <Text style={styles.gameOverTitle}>GAME OVER</Text>

      <Text style={styles.score}>Pontuação: {score}</Text>
      <Text style={styles.score}>Melhor: {best}</Text>

      <TouchableOpacity style={styles.playBtn} onPress={onRestart}>
        <Text style={styles.playText}>Reiniciar</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.playBtn, { backgroundColor: "#1976d2", marginTop: 10 }]}
        onPress={onBackToMenu}
      >
        <Text style={styles.playText}>Voltar ao Menu</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },

  gameOverTitle: {
    fontSize: 36,
    color: "#ff5252",
    marginBottom: 12,
    fontWeight: "700",
  },

  score: {
    fontSize: 20,
    color: "#fff",
    marginBottom: 6,
  },

  playBtn: {
    backgroundColor: "#4caf50",
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 10,
  },

  playText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
});
