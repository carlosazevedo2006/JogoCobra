import React from "react";
import { View, Animated, StyleSheet } from "react-native";
import SnakeSegment from "./SnakeSegment";
import EnemySnakeSegment from "./EnemySnakeSegment";
import Food from "./Food";

import { GRID_SIZE, CELULA } from "../utils/constants";
import { Posicao } from "../types/types";

interface GameBoardProps {
  cobra: Posicao[];
  cobraInimiga: Posicao[];
  comida: Posicao;
  animSegments: Animated.ValueXY[];
  eatAnim: Animated.Value;
  corCobra: string;
  modoSelecionado: string | null;
  panHandlers?: any;
}

export default function GameBoard({
  cobra,
  cobraInimiga,
  comida,
  animSegments,
  eatAnim,
  corCobra,
  modoSelecionado,
  panHandlers,
}: GameBoardProps) {
  return (
    <View style={styles.board} {...panHandlers}>
      {/* Grelha */}
      {Array.from({ length: GRID_SIZE }).map((_, row) =>
        Array.from({ length: GRID_SIZE }).map((_, col) => (
          <View
            key={`grid-${row}-${col}`}
            style={{
              position: "absolute",
              width: CELULA,
              height: CELULA,
              left: col * CELULA,
              top: row * CELULA,
              borderWidth: 0.5,
              borderColor: "#ddd",
              borderStyle: "dashed",
            }}
          />
        ))
      )}

      {/* Cobra do jogador */}
      {cobra.map((seg, idx) => {
        // segurança: evitar undefined no animSegments
        const anim =
          animSegments[idx] ||
          new Animated.ValueXY({
            x: seg.x * CELULA,
            y: seg.y * CELULA,
          });

        return (
          <SnakeSegment
            key={`seg-${idx}-${seg.x}-${seg.y}`}
            segment={seg}
            animation={anim}
            color={corCobra}
          />
        );
      })}

      {/* Cobra inimiga */}
      {modoSelecionado === "DIFICIL" &&
        (cobraInimiga || []).map((seg, idx) => (
          <EnemySnakeSegment key={`enemy-${idx}`} segment={seg} />
        ))}

      {/* Comida */}
      <Food comida={comida} eatAnim={eatAnim} />
    </View>
  );
}

const styles = StyleSheet.create({
  board: {
    width: GRID_SIZE * CELULA,
    height: GRID_SIZE * CELULA,
    backgroundColor: "#fff",
    borderWidth: 2,
    borderColor: "#555",
    position: "relative",
    overflow: "hidden",
  },
});
