// src/screens/Game.tsx
import React, { useRef, useState } from "react";
import { View, Text, StyleSheet, Animated } from "react-native";

import { Modo } from "../types/types";

// Screens
import WelcomeScreen from "./WelcomeScreen";
import PlayScreen from "./PlayScreen";
import ModeSelectionScreen from "./ModeSelectScreen";
import CountdownScreen from "./CountdownScreen";
import GameOverScreen from "./GameOverScreen";

// Components
import GameBoard from "../components/GameBoard";

// Hooks
import useSnakeMovement from "../hooks/useSnakeMovement";
import useEnemyMovement from "../hooks/useEnemyMovement";
import useGameLoop from "../hooks/useGameLoop";

// Utils
import { DIRECOES } from "../utils/constants";

export default function Game() {
  // fluxo principal
  const [showWelcome, setShowWelcome] = useState(true);
  const [showPlayScreen, setShowPlayScreen] = useState(false);
  const [showModeSelection, setShowModeSelection] = useState(false);

  const [modoSelecionado, setModoSelecionado] = useState<Modo | null>(null);
  const [contador, setContador] = useState<number | null>(null);
  const [gameOver, setGameOver] = useState(false);

  // refs necessárias
  const latestDirRef = useRef(DIRECOES.DIREITA);

  // 🔥🔥🔥 CORRIGIDO — eatAnim agora é Animated.Value(1)
  const eatAnim = useRef(new Animated.Value(1)).current;  

  const animSegments = useRef<any[]>([]);

  // hook da cobra
  const {
    cobra,
    direcao,
    comida,
    pontos,
    melhor,
    velocidade,
    corCobra,

    setDirecao,
    setCobra,
    setComida,
    setPontos,
    setVelocidade,
    setMelhor,
    setCorCobra,

    requestDirecao,
    step,
    resetCobra,
  } = useSnakeMovement({
    latestDirRef,
    eatAnim,
    animSegments,
    modoSelecionado,
  });

  // hook cobra inimiga (modo difícil)
  const { cobraInimiga, setCobraInimiga, moverCobraInimiga } =
    useEnemyMovement({
      modoSelecionado,
      cobra,
      terminarJogo: () => setGameOver(true),
    });

  // loop do jogo
  useGameLoop(isJogando(), velocidade, () => {
    step();
    moverCobraInimiga();
  });

  function isJogando() {
    return (
      !showWelcome &&
      !showPlayScreen &&
      !showModeSelection &&
      !gameOver &&
      contador === null
    );
  }

  // iniciar contagem
  function iniciarContagem() {
    setContador(3);
    let c = 3;

    const interval = setInterval(() => {
      c -= 1;
      setContador(c);
      if (c <= 0) {
        clearInterval(interval);
        setContador(null);
      }
    }, 1000);
  }

  // reiniciar jogo totalmente
  function reiniciar() {
    resetCobra();
    setCobraInimiga([{ x: 8, y: 8 }]);
    setPontos(0);
    setGameOver(false);
    iniciarContagem();
  }

  // -----------------------------------------------------------
  // RENDERIZAÇÃO DAS TELAS
  // -----------------------------------------------------------

  if (showWelcome) {
    return (
      <WelcomeScreen
        onContinue={() => {
          setShowWelcome(false);
          setShowPlayScreen(true);
        }}
      />
    );
  }

  if (showPlayScreen) {
    return (
      <PlayScreen
        onChooseMode={() => {
          setShowPlayScreen(false);
          setShowModeSelection(true);
        }}
      />
    );
  }

  if (showModeSelection) {
    return (
      <ModeSelectionScreen
        onSelect={(modo: Modo) => {
          setModoSelecionado(modo);
          setShowModeSelection(false);
          iniciarContagem();
        }}
      />
    );
  }

  if (contador !== null) {
    return <CountdownScreen value={contador} />;
  }

  if (gameOver) {
    return (
      <GameOverScreen
        pontos={pontos}
        melhor={melhor}
        onRestart={reiniciar}
        onMenu={() => {
          setShowModeSelection(true);
          setModoSelecionado(null);
        }}
      />
    );
  }

  // JOGO ATIVO
  return (
    <View style={styles.root}>
      <Text style={styles.score}>
        Modo: {modoSelecionado} | Pontos: {pontos} | Melhor: {melhor}
      </Text>

      <GameBoard
        cobra={cobra}
        cobraInimiga={cobraInimiga}
        comida={comida}
        animSegments={animSegments.current}
        eatAnim={eatAnim}
        corCobra={corCobra}
        modoSelecionado={modoSelecionado}
        panHandlers={{}}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#111",
    alignItems: "center",
    justifyContent: "center",
  },
  score: {
    color: "#fff",
    marginBottom: 16,
    fontSize: 16,
  },
});
